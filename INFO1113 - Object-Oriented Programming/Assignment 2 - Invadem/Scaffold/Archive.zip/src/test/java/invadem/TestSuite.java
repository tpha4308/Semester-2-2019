package invadem;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({TankTest.class, BarrierTest.class, InvaderTest.class, ProjectileTest.class})

public class TestSuite {

}
